package com.company;


import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) {

	VeiculoNormal v1 = new VeiculoNormal("61-EE-21", "Skoda", "Fabia", 2006, 76.3, 4.5, 0, 0.0, 0, 0);
	VeiculoNormal v2 = new VeiculoNormal("71-RE-01", "Opel", "Corsa", 2008, 67.7, 5, 0, 0.0, 0, 0);
	VeiculoNormal v3 = new VeiculoNormal("11-FG-16", "Porsche", "Panamera", 2009, 89.1, 3.5,0, 0.0, 0, 0);
	VeiculoNormal v4 = new VeiculoNormal("55-TY-09", "Skoda", "Scala", 2010, 75.6, 4.8, 0,0.0, 0, 0);
    VeiculoOcasiao v5 = new VeiculoOcasiao("56-GG-78", "Fiat", "Punto", 2006, 72.3, 3.7, 0,0.0, 0, 0,true);
    VeiculoOcasiao v6 = new VeiculoOcasiao("05-HJ-72", "Porsche", "Carrera", 2009, 95.3, 5.2, 0,0.0, 0, 0,false);
    System.out.println("Carros gerados\n");

    DriveIt drive = new DriveIt();
    System.out.println("DriveIt gerado\n");

    /* 1 */
    /* e) */
    drive.adiciona(v1); drive.adiciona(v2); drive.adiciona(v3); drive.adiciona(v4); drive.adiciona(v5); drive.adiciona(v6);
    System.out.println("Carros adicionados ao driveIt\n");
    System.out.println(drive);

    /* a) */
    System.out.println("Existe algum com a matricula 56-GH-78? -> " + drive.existeVeiculo("56-GH-78") + "\n");
    System.out.println("E com a matricula 11-FG-16? -> " + drive.existeVeiculo("11-FG-16")+ "\n");

    /* b) */
    System.out.println("Quantidade de carros na estrutura: " + drive.quantos() + "\n");

    /* c) */
    System.out.println("Quantidade de carros Porsche -> " + drive.quantos("Porsche"));
    System.out.println("Quantidade de carros Fiat -> " + drive.quantos("Fiat"));
    System.out.println("Quantidade de carros Skoda -> " + drive.quantos("Skoda"));

    /* d) */
    Veiculo obtido = drive.getVeiculo("05-HJ-72");
    System.out.println("\nVeiculo obtido");
    System.out.println(obtido);

    /* f) */
    List<Veiculo> listaveiculos = drive.getVeiculosList();
    System.out.println("\nLista de todos os veiculos inseridos na estrutura:");
    System.out.println(listaveiculos);

    /* g) */
    VeiculoNormal v7 = new VeiculoNormal("78-RG-24","Lamborghini", "Aventador", 2005, 103.2, 5.6, 0, 0.0, 0, 0);
    VeiculoNormal v8 = new VeiculoNormal("35-AA-16","Fiat", "500", 2002, 65.8, 5.6, 0, 0.0, 0, 0);
    Set<Veiculo> teste = new HashSet<>();
    teste.add(v7); teste.add(v8);
    /* adicionam-se repetidos para ver se ignora */ teste.add(v2); teste.add(v5);
    drive.adiciona(teste);
    System.out.println("\nConjunto dos veículos adicionado ao HashMap, HashMap atualizado -> "); System.out.println(drive);
    System.out.println(drive.quantos());

    /* h) */
    System.out.println("\nVeiculo antes de registar aluguer: "); System.out.println(drive.getVeiculo("35-AA-16"));
    drive.registarAluguer("35-AA-16", 643);
    System.out.println("\nVeiculo depois de registar aluguer: "); System.out.println(drive.getVeiculo("35-AA-16"));

    /* i) */
    System.out.println("\nVeiculo antes de classificar: "); System.out.println(drive.getVeiculo("78-RG-24"));
    drive.classificarVeiculo("78-RG-24", 9);
    System.out.println("\nVeiculo depois de classificar: "); System.out.println(drive.getVeiculo("78-RG-24"));

    /* j) */
    System.out.println("\nCusto real por km do skoda fabia -> " + drive.custoRealKm("61-EE-21"));
    drive.ordenarVeiculos();
    System.out.println(drive);

    // ------------ FASE 2 -------------

        /*a) */
        drive.ordenarVeiculos();
        System.out.println(drive);



    }
}
